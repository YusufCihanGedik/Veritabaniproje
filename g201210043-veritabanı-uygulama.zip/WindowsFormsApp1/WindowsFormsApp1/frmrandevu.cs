﻿using System;
using System.Collections.Generic;

using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApp1
{
    public partial class frmrandevu : Form
    {
        public frmrandevu()
        {
            InitializeComponent();
        }
        NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=veritabaniproje; user ID=postgres; password=Yc.gedik.12.10 ");
        private void button4_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from randevular";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void btnekle_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut1 = new NpgsqlCommand("insert into randevular(randevularıd,randevu,hastaıd,hastaneid)values (@p1,@p2,@p3,@p4)", baglanti);
            komut1.Parameters.AddWithValue("@p1", int.Parse(txtrandevuid.Text));
            komut1.Parameters.AddWithValue("@p2", txtrandevu.Text);
            komut1.Parameters.AddWithValue("@p3", int.Parse(txthastaid.Text));
            komut1.Parameters.AddWithValue("@p4", int.Parse(txthastane.Text));
            komut1.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Ekleme Başarılı Bir Şekilde Gerçekleşti");
        }
        private void btnsil_Click(object sender, EventArgs e)
        {
            baglanti.Open();

            NpgsqlCommand komut2 = new NpgsqlCommand("Delete From randevular where randevularıd=@p1", baglanti);
            DialogResult dr = new DialogResult();
            dr = MessageBox.Show("Silmek istediğinize emin misiniz?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                komut2.Parameters.AddWithValue("@p1", int.Parse(txtrandevuid.Text));
                komut2.ExecuteNonQuery();
                baglanti.Close();
                MessageBox.Show("Randevu Silme İşlemi Başarı İle Gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut3 = new NpgsqlCommand("update randevular set randevu=@p2,hastaıd=@p3,hastaneid=@p4 where randevularıd=@p1", baglanti);
            komut3.Parameters.AddWithValue("@p1", int.Parse(txtrandevuid.Text));
            komut3.Parameters.AddWithValue("@p2", txtrandevu.Text);
            komut3.Parameters.AddWithValue("@p3", int.Parse(txthastaid.Text));
            komut3.Parameters.AddWithValue("@p4", int.Parse(txthastane.Text));
        

            komut3.ExecuteNonQuery();
            MessageBox.Show("Randevu Güncelleme İşlemi Başarılı Bir Şekilde Gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            baglanti.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from hastane ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void btnilçelistele_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from ilce ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void btnillistele_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from il ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void btnkangrblistele_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from kangrubu ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void btnkangrubulistele_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from hastalık ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormAna frm3 = new FormAna();
            frm3.Show();
          
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string sorgu = "select * from hasta ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }
    }
}
