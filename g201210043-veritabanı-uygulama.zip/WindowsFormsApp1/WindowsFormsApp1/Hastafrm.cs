﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApp1
{
    public partial class Hastafrm : Form
    {
        public Hastafrm()
        {
            InitializeComponent();
        }
       
        NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=veritabaniproje; user ID=postgres; password=Yc.gedik.12.10 ");
        private void btnliste_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from hasta ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void btnekle_Click(object sender, EventArgs e)
        {
            //hasta işlemlerindeki diğer verilerin bağlantısını tanımlamayı unutma

            baglanti.Open();
            NpgsqlCommand komut1 = new NpgsqlCommand("insert into hasta(hastaıd,ad,soyad,hastail,kangrubuid,hastalıkid,ilid,ilceid,tckimlikno,iletisim)values (@p1,@p2,@p3,@p4,@p5,@p6,@p7,@p8,@p9,@p10)", baglanti);
            komut1.Parameters.AddWithValue("@p1", int.Parse(txtHastaıd.Text));
            komut1.Parameters.AddWithValue("@p2", txthastaad.Text);
            komut1.Parameters.AddWithValue("@p3", int.Parse(txthastailıd.Text));
            komut1.Parameters.AddWithValue("@p4", int.Parse(txthastailıd.Text));
            komut1.Parameters.AddWithValue("@p5", int.Parse(txtkangrubuıd.Text));
            komut1.Parameters.AddWithValue("@p6", int.Parse(txthastalıkar.Text));
            komut1.Parameters.AddWithValue("@p7", int.Parse(txtilid.Text));
            komut1.Parameters.AddWithValue("@p8", int.Parse(txthastailçeid.Text));
            komut1.Parameters.AddWithValue("@p9", txthastatckimliko.Text);
            komut1.Parameters.AddWithValue("@p10", txtiletişim.Text);
            

            komut1.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Ekleme Başarılı Bir Şekilde Gerçekleşti");
        }

        private void btnsil_Click(object sender, EventArgs e)
        {
            baglanti.Open();

            NpgsqlCommand komut2 = new NpgsqlCommand("Delete From hasta where hastaıd=@p1", baglanti);
            DialogResult dr = new DialogResult();
            dr = MessageBox.Show("Silmek istediğinize emin misiniz?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                komut2.Parameters.AddWithValue("@p1", int.Parse(txtHastaıd.Text));
                komut2.ExecuteNonQuery();
                baglanti.Close();
                MessageBox.Show("Hasta Silme İşlemi Başarı İle Gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }


        }

        private void txtara_TextChanged(object sender, EventArgs e)
        {
            baglanti.Open();
            DataTable tbl = new DataTable();
            if (cmbara.Text=="Ad")
            {
                string search = "select * from public.hasta where ad like '%"+txtara.Text+"%'";
                NpgsqlDataAdapter ara = new NpgsqlDataAdapter("select * from hasta where ad like '%"+txtara.Text+"%'", baglanti);
                ara.Fill(tbl);
            }
            if (cmbara.Text == "ID")
            {
                string search = "select * from public.hasta where hastaıd::text like '%" + txtara.Text + "%'";
                NpgsqlDataAdapter ara = new NpgsqlDataAdapter("select * from hasta where hastaıd::text like '%" + txtara.Text + "%'", baglanti);
                ara.Fill(tbl);
            }

            if (cmbara.Text == "Soyad")
            {
                string search = "select * from public.hasta where soyad like '%"+ txtara.Text +"%'";
                NpgsqlDataAdapter ara = new NpgsqlDataAdapter("select * from hasta where soyad like '%"+txtara.Text+"%'", baglanti);
                ara.Fill(tbl);
            }
            baglanti.Close();
            dataGridView1.DataSource = tbl;

        }

        private void btngüncelle_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut3 = new NpgsqlCommand("update hasta set ad=@p2,soyad=@p3,hastail=@p4,ilid=@p5,kangrubuid=@p6,ilceid=@p7,hastalıkid=@p8,tckimlikno=@p9,iletisim=@p10  where hastaıd=@p1", baglanti);
            komut3.Parameters.AddWithValue("@p1", int.Parse(txtHastaıd.Text));
            komut3.Parameters.AddWithValue("@p2", txthastaad.Text);
            komut3.Parameters.AddWithValue("@p3", txthastasoyad.Text);
            komut3.Parameters.AddWithValue("@p4", int.Parse(txthastailıd.Text));
            komut3.Parameters.AddWithValue("@p5", int.Parse(txtilid.Text));
            komut3.Parameters.AddWithValue("@p6", int.Parse(txtkangrubuıd.Text));
            komut3.Parameters.AddWithValue("@p7", int.Parse(txthastailçeid.Text));
            komut3.Parameters.AddWithValue("@p8", int.Parse(txthastalıkar.Text));
            komut3.Parameters.AddWithValue("@p9", txthastatckimliko.Text);
            komut3.Parameters.AddWithValue("@p10", txtiletişim.Text);


            komut3.ExecuteNonQuery();
            MessageBox.Show("Hasta Güncelleme İşlemi Başarılı Bir Şekilde Gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            baglanti.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 frm2 = new Form1();
            frm2.Show();
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormAna frm3 = new FormAna();
            frm3.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from ilce ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from il ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from kangrubu ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from hastalık ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            string sorgu = "select * from randevular ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }
    } 
}
