﻿
using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;


namespace WindowsFormsApp1
{
    public partial class frmsonuc : Form
    {
        public frmsonuc()
        {
            InitializeComponent();
        }
        NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=veritabaniproje; user ID=postgres; password=Yc.gedik.12.10 ");
        private void btnekle_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut1 = new NpgsqlCommand("insert into muayne (muayneıd,muaynetipi,hastaid)values (@p1,@p2,@p3)", baglanti);
            komut1.Parameters.AddWithValue("@p1", int.Parse(txtmuayneıd1.Text));
            komut1.Parameters.AddWithValue("@p2", txtmuaynetipi.Text);
            komut1.Parameters.AddWithValue("@p3", int.Parse(txthastaid.Text));

            komut1.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Ekleme Başarılı Bir Şekilde Gerçekleşti");
  
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from muayne ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button3_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut3 = new NpgsqlCommand("update muayne set muaynetipi=@p2,hastaid=@p3 where muayneıd=@p1", baglanti);
            komut3.Parameters.AddWithValue("@p1", int.Parse(txtmuayneıd1.Text));
            komut3.Parameters.AddWithValue("@p2", txtmuaynetipi.Text);
            komut3.Parameters.AddWithValue("@p3", int.Parse(txthastaid.Text));
            komut3.ExecuteNonQuery();
            MessageBox.Show("Muayne Güncelleme İşlemi Başarılı Bir Şekilde Gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            baglanti.Close();
        }

        private void btnsil_Click(object sender, EventArgs e)
        {
            baglanti.Open();

            NpgsqlCommand komut2 = new NpgsqlCommand("Delete From muayne where muayneıd=@p1", baglanti);
            DialogResult dr = new DialogResult();
            dr = MessageBox.Show("Silmek istediğinize emin misiniz?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                komut2.Parameters.AddWithValue("@p1", int.Parse(txtmuayneıd1.Text));
                komut2.ExecuteNonQuery();
                baglanti.Close();
                MessageBox.Show("Muayne Silme İşlemi Başarı İle Gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }
        //2.dörtlü

        private void button7_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut1 = new NpgsqlCommand("insert into test (testıd,testler,muaynesonucid,labıd)values (@p1,@p2,@p3,@p4)", baglanti);
            komut1.Parameters.AddWithValue("@p1", int.Parse(txttestıd1.Text));
            komut1.Parameters.AddWithValue("@p2", txttestler1.Text);
            komut1.Parameters.AddWithValue("@p3", int.Parse(txttestmuaynesonuc1.Text));
            komut1.Parameters.AddWithValue("@p4", int.Parse(txtlabtestsonuc.Text));

            komut1.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Ekleme Başarılı Bir Şekilde Gerçekleşti");

        }

        private void button5_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut3 = new NpgsqlCommand("update test set testler=@p2,muaynesonucid=@p3,labıd=@p4 where testıd=@p1", baglanti);
            komut3.Parameters.AddWithValue("@p1", int.Parse(txttestıd1.Text));
            komut3.Parameters.AddWithValue("@p2", txttestler1.Text);
            komut3.Parameters.AddWithValue("@p3", int.Parse(txttestmuaynesonuc1.Text));
            komut3.Parameters.AddWithValue("@p4", int.Parse(txtlabtestsonuc.Text));
            komut3.ExecuteNonQuery();
            MessageBox.Show("Test Güncelleme İşlemi Başarılı Bir Şekilde Gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            baglanti.Close();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            baglanti.Open();

            NpgsqlCommand komut2 = new NpgsqlCommand("Delete From test where testıd=@p1", baglanti);
            DialogResult dr = new DialogResult();
            dr = MessageBox.Show("Silmek istediğinize emin misiniz?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                komut2.Parameters.AddWithValue("@p1", int.Parse(txttestıd1.Text));
                komut2.ExecuteNonQuery();
                baglanti.Close();
                MessageBox.Show("Test Silme İşlemi Başarı İle Gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from test ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }
        //2.dörtlü
        private void button15_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut1 = new NpgsqlCommand("insert into testsonuc(testsonuclarııd,sonuclar,teshisid,labıd)values (@p1,@p2,@p3,@p4)", baglanti);
            komut1.Parameters.AddWithValue("@p1", int.Parse(txttestsonuclarııd.Text));
            komut1.Parameters.AddWithValue("@p2", txtsonuclar.Text);
            komut1.Parameters.AddWithValue("@p3", int.Parse(txtteshisid.Text));
            komut1.Parameters.AddWithValue("@p4", int.Parse(txttestsonuclabıd1.Text));


            komut1.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Ekleme Başarılı Bir Şekilde Gerçekleşti");
        }

        private void button13_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut3 = new NpgsqlCommand("update testsonuc set sonuclar=@p2,teshisid=@p3,@p4 where testsonuclarııd=@p1", baglanti);
            komut3.Parameters.AddWithValue("@p1", int.Parse(txttestsonuclarııd.Text));
            komut3.Parameters.AddWithValue("@p2", txtsonuclar.Text);
            komut3.Parameters.AddWithValue("@p3", int.Parse(txtteshisid.Text));
            komut3.Parameters.AddWithValue("@p4", int.Parse(txttestsonuclabıd1.Text));
            komut3.ExecuteNonQuery();
            MessageBox.Show("Test Sonuç Güncelleme İşlemi Başarılı Bir Şekilde Gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            baglanti.Close();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            baglanti.Open();

            NpgsqlCommand komut2 = new NpgsqlCommand("Delete From testsonuc where testsonuclarııd=@p1", baglanti);
            DialogResult dr = new DialogResult();
            dr = MessageBox.Show("Silmek istediğinize emin misiniz?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                komut2.Parameters.AddWithValue("@p1", int.Parse(txttestsonuclarııd.Text));
                komut2.ExecuteNonQuery();
                baglanti.Close();
                MessageBox.Show("Test Sonuçları Silme İşlemi Başarı İle Gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from testsonuc ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }
        //2.dörtlü
        private void button11_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut1 = new NpgsqlCommand("insert into teshis(teshisıd,teshisler,hastaid)values (@p1,@p2,@p3)", baglanti);
            komut1.Parameters.AddWithValue("@p1", int.Parse(txtteshisanaıd.Text));
            komut1.Parameters.AddWithValue("@p2", txtteshisler.Text);
            komut1.Parameters.AddWithValue("@p3", int.Parse(txthastaıd2.Text));


            komut1.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Ekleme Başarılı Bir Şekilde Gerçekleşti");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut3 = new NpgsqlCommand("update teshis set teshisler=@p2,hastaid=@p3 where teshisıd=@p1", baglanti);
            komut3.Parameters.AddWithValue("@p1", int.Parse(txtteshisanaıd.Text));
            komut3.Parameters.AddWithValue("@p2", txtteshisler.Text);
            komut3.Parameters.AddWithValue("@p3", int.Parse(txthastaıd2.Text));
            komut3.ExecuteNonQuery();
            MessageBox.Show("Teşhis Güncelleme İşlemi Başarılı Bir Şekilde Gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            baglanti.Close();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            baglanti.Open();

            NpgsqlCommand komut2 = new NpgsqlCommand("Delete From teshis where teshisıd=@p1", baglanti);
            DialogResult dr = new DialogResult();
            dr = MessageBox.Show("Silmek istediğinize emin misiniz?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                komut2.Parameters.AddWithValue("@p1", int.Parse(txtteshisanaıd.Text));
                komut2.ExecuteNonQuery();
                baglanti.Close();
                MessageBox.Show("Teşhis Silme İşlemi Başarı İle Gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from teshis ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button16_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from muaynesonuc ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button19_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut1 = new NpgsqlCommand("insert into muaynesonuc(muaynesonucid,sonuclar,hastaid,muayneid)values (@p1,@p2,@p3,@p4)", baglanti);
            komut1.Parameters.AddWithValue("@p1", int.Parse(txtmuaynesonuc1.Text));
            komut1.Parameters.AddWithValue("@p2", txtmuaynesonuc2.Text);
            komut1.Parameters.AddWithValue("@p3", int.Parse(txtmuaynesonuc3.Text));
            komut1.Parameters.AddWithValue("@p4", int.Parse(txtmuaynesonuc4.Text));


            komut1.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Ekleme Başarılı Bir Şekilde Gerçekleşti");
        }

        private void button18_Click(object sender, EventArgs e)
        {
            baglanti.Open();

            NpgsqlCommand komut2 = new NpgsqlCommand("Delete From muaynesonuc where muaynesonucid=@p1", baglanti);
            DialogResult dr = new DialogResult();
            dr = MessageBox.Show("Silmek istediğinize emin misiniz?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                komut2.Parameters.AddWithValue("@p1", int.Parse(txtmuaynesonuc1.Text));
                komut2.ExecuteNonQuery();
                baglanti.Close();
                MessageBox.Show("Muayne Sonuc Silme İşlemi Başarı İle Gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut3 = new NpgsqlCommand("update muaynesonuc set sonuclar=@p2,hastaid=@p3,muayneid=@p4 where muaynesonucid=@p1", baglanti);
            komut3.Parameters.AddWithValue("@p1", int.Parse(txtmuaynesonuc1.Text));
            komut3.Parameters.AddWithValue("@p2", txtmuaynesonuc2.Text);
            komut3.Parameters.AddWithValue("@p3", int.Parse(txtmuaynesonuc3.Text));
            komut3.Parameters.AddWithValue("@p4", int.Parse(txtmuaynesonuc4.Text));
            komut3.ExecuteNonQuery();
            MessageBox.Show("Muayne Sonuç Güncelleme İşlemi Başarılı Bir Şekilde Gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            baglanti.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from hasta ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button20_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from lab ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }
    }
}
