﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class FormAna : Form
    {
        public FormAna()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Hastafrm frm1 = new Hastafrm();
            frm1.Show();
            


        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 frm2 = new Form1();
            frm2.Show();
            

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            frmrandevu frm3 = new frmrandevu();
            frm3.Show();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            frmsonuc frm4 = new frmsonuc();
            frm4.Show();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            frmlab frmlab1 = new frmlab();
            frmlab1.Show();

        }

        private void button7_Click(object sender, EventArgs e)
        {
            frmililce fremililce2 = new frmililce();
            fremililce2.Show();

        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form2 frmhastanepol = new Form2();
            frmhastanepol.Show();
        }
    }
}
