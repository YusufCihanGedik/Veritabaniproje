﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApp1
{
    public partial class frmililce : Form
    {
        public frmililce()
        {
            InitializeComponent();
        }
        NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=veritabaniproje; user ID=postgres; password=Yc.gedik.12.10 ");
        private void button4_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from il ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from ilce ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void btnekle_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut1 = new NpgsqlCommand("insert into il (ilid,iller)values (@p1,@p2)", baglanti);
            komut1.Parameters.AddWithValue("@p1", int.Parse(txtilanaıd.Text));
            komut1.Parameters.AddWithValue("@p2", txtillerana.Text);

            komut1.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Ekleme Başarılı Bir Şekilde Gerçekleşti");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut1 = new NpgsqlCommand("insert into ilce (ilceid,ilceler,ilid) values (@p1,@p2,@p3)", baglanti);
            komut1.Parameters.AddWithValue("@p1", int.Parse(txtiilceidana.Text));
            komut1.Parameters.AddWithValue("@p2", txtilcelerana.Text);
            komut1.Parameters.AddWithValue("@p3", int.Parse(txtililceana.Text));

            komut1.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Ekleme Başarılı Bir Şekilde Gerçekleşti");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut3 = new NpgsqlCommand("update il set iller=@p2 where ilid=@p1", baglanti);
            komut3.Parameters.AddWithValue("@p1", int.Parse(txtilanaıd.Text));
            komut3.Parameters.AddWithValue("@p2", txtillerana.Text);



            komut3.ExecuteNonQuery();
            MessageBox.Show("Güncelleme İşlemi Başarılı Bir Şekilde Gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            baglanti.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {

            baglanti.Open();
            NpgsqlCommand komut3 = new NpgsqlCommand("update ilce set ilceler=@p2,ilid=@p3 where ilceid=@p1", baglanti);
            komut3.Parameters.AddWithValue("@p1", int.Parse(txtiilceidana.Text));
            komut3.Parameters.AddWithValue("@p2", txtilcelerana.Text);
            komut3.Parameters.AddWithValue("@p3", int.Parse(txtililceana.Text));



            komut3.ExecuteNonQuery();
            MessageBox.Show("Güncelleme İşlemi Başarılı Bir Şekilde Gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            baglanti.Close();
        }

        private void btnsil_Click(object sender, EventArgs e)
        {
            baglanti.Open();

            NpgsqlCommand komut2 = new NpgsqlCommand("Delete From il where ilid=@p1", baglanti);
            DialogResult dr = new DialogResult();
            dr = MessageBox.Show("Silmek istediğinize emin misiniz?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                komut2.Parameters.AddWithValue("@p1", int.Parse(txtilanaıd.Text));
                komut2.ExecuteNonQuery();
                baglanti.Close();
                MessageBox.Show("İl uygulamaları Silme İşlemi Başarı İle Gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            baglanti.Open();

            NpgsqlCommand komut2 = new NpgsqlCommand("Delete From ilce where ilceid=@p1", baglanti);
            DialogResult dr = new DialogResult();
            dr = MessageBox.Show("Silmek istediğinize emin misiniz?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                komut2.Parameters.AddWithValue("@p1", int.Parse(txtiilceidana.Text));
                komut2.ExecuteNonQuery();
                baglanti.Close();
                MessageBox.Show("İl uygulamaları Silme İşlemi Başarı İle Gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

      
    }
}
