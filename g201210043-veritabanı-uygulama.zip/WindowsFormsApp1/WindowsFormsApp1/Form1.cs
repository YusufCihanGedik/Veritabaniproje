﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=veritabaniproje; user ID=postgres; password=Yc.gedik.12.10 ");
        private void btnliste_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from doktor ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void btnekleme_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut1 = new NpgsqlCommand("insert into doktor(doktorid,doktorlar,ilid,ilceid,doktormaasid,kangrubuid,unvanid,bolum)values (@p1,@p2,@p3,@p4,@p5,@p6,@p7,@p8 )", baglanti);
            komut1.Parameters.AddWithValue("@p1", int.Parse( TxtdoktoriD.Text));
            komut1.Parameters.AddWithValue("@p2", Txtdoktorad.Text);
            komut1.Parameters.AddWithValue("@p3", int.Parse(txtdoktorilıd.Text));
            komut1.Parameters.AddWithValue("@p4", int.Parse(txtdoktorilçeid.Text));
            komut1.Parameters.AddWithValue("@p5", int.Parse(txtdoktormaas.Text));
            komut1.Parameters.AddWithValue("@p6", int.Parse(txtkangrubudok.Text));
            komut1.Parameters.AddWithValue("@p7", int.Parse(txtunvanekle.Text));
            komut1.Parameters.AddWithValue("@p8", int.Parse(txtbölümekle.Text));
            komut1.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Ekleme Başarılı Bir Şekilde Gerçekleşti");

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Hastafrm frm1 = new Hastafrm();
            frm1.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormAna frm3 = new FormAna();
            frm3.Show();
        }

        private void btnsil_Click(object sender, EventArgs e)
        {
            baglanti.Open();

            NpgsqlCommand komut2 = new NpgsqlCommand("Delete From doktor where doktorid=@p1", baglanti);
            DialogResult dr = new DialogResult();
            dr = MessageBox.Show("Silmek istediğinize emin misiniz?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                komut2.Parameters.AddWithValue("@p1", int.Parse(TxtdoktoriD.Text));
                komut2.ExecuteNonQuery();
                baglanti.Close();
                MessageBox.Show("Silme İşlemi Başarı İle Gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void txtara_TextChanged(object sender, EventArgs e)
        {
            baglanti.Open();
            DataTable tbl = new DataTable();
            if (cmbara.Text == "Doktorlar")
            {
                string search = "select * from public.doktor where doktorlar like '%" + txtara.Text + "%'";
                NpgsqlDataAdapter ara = new NpgsqlDataAdapter("select * from doktor where doktorlar like '%" + txtara.Text + "%'", baglanti);
                ara.Fill(tbl);
            }
            if (cmbara.Text == "ID")
            {
                string search = "select * from public.doktor where doktorid::text like '%" + txtara.Text + "%'";
                NpgsqlDataAdapter ara = new NpgsqlDataAdapter("select * from doktor where doktorid::text like '%" + txtara.Text + "%'", baglanti);
                ara.Fill(tbl);
            }


            baglanti.Close();
            dataGridView1.DataSource = tbl;
        }

        private void btngüncelle_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut3 = new NpgsqlCommand("update doktor set doktorlar=@p2,ilid=@p3,ilceid=@p4,kangrubuid=@p5,doktormaasid=@p6,unvanid=@p7,bolum=@p8 where doktorid=@p1", baglanti);
            komut3.Parameters.AddWithValue("@p1", int.Parse(TxtdoktoriD.Text));
            komut3.Parameters.AddWithValue("@p2", Txtdoktorad.Text);
            komut3.Parameters.AddWithValue("@p3", int.Parse(txtdoktorilıd.Text));
            komut3.Parameters.AddWithValue("@p4", int.Parse(txtdoktorilçeid.Text));
            komut3.Parameters.AddWithValue("@p5", int.Parse(txtkangrubudok.Text));
            komut3.Parameters.AddWithValue("@p6", int.Parse(txtdoktormaas.Text));
            komut3.Parameters.AddWithValue("@p7", int.Parse(txtunvanekle.Text));
            komut3.Parameters.AddWithValue("@p8", int.Parse(txtbölümekle.Text));
            komut3.ExecuteNonQuery();
            MessageBox.Show("Güncelleme İşlemi Başarılı Bir Şekilde Gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            baglanti.Close();
        }

       

        private void button4_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from il ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from ilce ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from kangrubu ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from doktor_maas ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from unvan ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button8_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut1 = new NpgsqlCommand("insert into unvan(unvan,unvanid)values (@p1,@p2)", baglanti);
            komut1.Parameters.AddWithValue("@p1", txtunvanlar12.Text);
            komut1.Parameters.AddWithValue("@p2", int.Parse(txtünvanlarıd.Text));
          
            komut1.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Ekleme Başarılı Bir Şekilde Gerçekleşti");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut3 = new NpgsqlCommand("update unvan set unvan=@p2 where unvanid=@p1", baglanti);
            komut3.Parameters.AddWithValue("@p1", int.Parse(txtünvanlarıd.Text));
            komut3.Parameters.AddWithValue("@p2", txtunvanlar12.Text);
           
            komut3.ExecuteNonQuery();
            MessageBox.Show("Ünvan Güncelleme İşlemi Başarılı Bir Şekilde Gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            baglanti.Close();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            baglanti.Open();

            NpgsqlCommand komut2 = new NpgsqlCommand("Delete From unvan where unvanid=@p1", baglanti);
            DialogResult dr = new DialogResult();
            dr = MessageBox.Show("Silmek istediğinize emin misiniz?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                komut2.Parameters.AddWithValue("@p1", int.Parse(txtünvanlarıd.Text));
                komut2.ExecuteNonQuery();
                baglanti.Close();
                MessageBox.Show("Ünvan Silme İşlemi Başarı İle Gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from bolumler ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }
    }
}
