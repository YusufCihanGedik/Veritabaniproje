﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=veritabaniproje; user ID=postgres; password=Yc.gedik.12.10 ");
        private void btnekle_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut1 = new NpgsqlCommand("insert into hastane(hastaneid,hastaneler,hastanetürü,ilid)values (@p1,@p2,@p3,@p4)", baglanti);
            komut1.Parameters.AddWithValue("@p1", int.Parse(txtHastane1.Text));
            komut1.Parameters.AddWithValue("@p2", txthastane2.Text);
            komut1.Parameters.AddWithValue("@p3", txthastane3.Text);
            komut1.Parameters.AddWithValue("@p4", int.Parse(txthastane4.Text));


            komut1.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Ekleme Başarılı Bir Şekilde Gerçekleşti");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from hastane ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button3_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut3 = new NpgsqlCommand("update hastane set hastaneler=@p2,hastanetürü=@p3,ilid=@p4 where hastaneid=@p1", baglanti);
            komut3.Parameters.AddWithValue("@p1", int.Parse(txtHastane1.Text));
            komut3.Parameters.AddWithValue("@p2", txthastane2.Text);
            komut3.Parameters.AddWithValue("@p3", txthastane3.Text);
            komut3.Parameters.AddWithValue("@p4", int.Parse(txthastane4.Text));
            komut3.ExecuteNonQuery();
            MessageBox.Show("Hastane Güncelleme İşlemi Başarılı Bir Şekilde Gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            baglanti.Close();
        }

        private void btnsil_Click(object sender, EventArgs e)
        {
            baglanti.Open();

            NpgsqlCommand komut2 = new NpgsqlCommand("Delete From hastane where hastaneid=@p1", baglanti);
            DialogResult dr = new DialogResult();
            dr = MessageBox.Show("Silmek istediğinize emin misiniz?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                komut2.Parameters.AddWithValue("@p1", int.Parse(txtHastane1.Text));
                komut2.ExecuteNonQuery();
                baglanti.Close();
                MessageBox.Show("Hastane uygulamaları Silme İşlemi Başarı İle Gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from bolumler ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button5_Click(object sender, EventArgs e)
        {
            baglanti.Open();

            NpgsqlCommand komut2 = new NpgsqlCommand("Delete From bolumler where bolumlerid=@p1", baglanti);
            DialogResult dr = new DialogResult();
            dr = MessageBox.Show("Silmek istediğinize emin misiniz?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                komut2.Parameters.AddWithValue("@p1", int.Parse(txtbölümler1.Text));
                komut2.ExecuteNonQuery();
                baglanti.Close();
                MessageBox.Show("Hastane Bölüm uygulamaları Silme İşlemi Başarı İle Gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut1 = new NpgsqlCommand("insert into bolumler(bolumlerid,bolumler,hastaneid)values (@p1,@p2,@p3)", baglanti);
            komut1.Parameters.AddWithValue("@p1", int.Parse(txtbölümler1.Text));
            komut1.Parameters.AddWithValue("@p2", txtbölümler2.Text);
            komut1.Parameters.AddWithValue("@p3", int.Parse(txtbolumler3.Text));


            komut1.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Ekleme Başarılı Bir Şekilde Gerçekleşti");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut3 = new NpgsqlCommand("update bolumler set bolumler=@p2,hastaneid=@p3 where bolumlerid=@p1", baglanti);
            komut3.Parameters.AddWithValue("@p1", int.Parse(txtbölümler1.Text));
            komut3.Parameters.AddWithValue("@p2", txtbölümler2.Text);
            komut3.Parameters.AddWithValue("@p3", int.Parse(txtbolumler3.Text));
            komut3.ExecuteNonQuery();
            MessageBox.Show("Bölüm Güncelleme İşlemi Başarılı Bir Şekilde Gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            baglanti.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from il ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }
    }
}
