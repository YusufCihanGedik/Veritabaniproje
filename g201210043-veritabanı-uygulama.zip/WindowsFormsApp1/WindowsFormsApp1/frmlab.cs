﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;


namespace WindowsFormsApp1
{
    public partial class frmlab : Form
    {
        public frmlab()
        {
            InitializeComponent();
        }
        NpgsqlConnection baglanti = new NpgsqlConnection("server=localHost; port=5432; Database=veritabaniproje; user ID=postgres; password=Yc.gedik.12.10 ");

        private void button4_Click(object sender, EventArgs e)
        {

            string sorgu = "select * from lab ";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void btnekle_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut1 = new NpgsqlCommand("insert into lab (labıd,labuygulamaları)values (@p1,@p2)", baglanti);
            komut1.Parameters.AddWithValue("@p1", int.Parse(txtlabıd.Text));
            komut1.Parameters.AddWithValue("@p2", txtlabuygulamaları.Text);
           
            komut1.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Ekleme Başarılı Bir Şekilde Gerçekleşti");
        }

        private void btnsil_Click(object sender, EventArgs e)
        {
            baglanti.Open();

            NpgsqlCommand komut2 = new NpgsqlCommand("Delete From lab where labıd=@p1", baglanti);
            DialogResult dr = new DialogResult();
            dr = MessageBox.Show("Silmek istediğinize emin misiniz?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                komut2.Parameters.AddWithValue("@p1", int.Parse(txtlabıd.Text));
                komut2.ExecuteNonQuery();
                baglanti.Close();
                MessageBox.Show("Lab uygulamaları Silme İşlemi Başarı İle Gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            baglanti.Open();
            NpgsqlCommand komut3 = new NpgsqlCommand("update lab set labuygulamaları=@p2 where labıd=@p1", baglanti);
            komut3.Parameters.AddWithValue("@p1", int.Parse(txtlabıd.Text));
            komut3.Parameters.AddWithValue("@p2", txtlabuygulamaları.Text);
           


            komut3.ExecuteNonQuery();
            MessageBox.Show(" Güncelleme İşlemi Başarılı Bir Şekilde Gerçekleşti", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            baglanti.Close();
        }

        
    }
}
